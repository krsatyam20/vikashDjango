from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def index(request):
    return HttpResponse("<html><head><title>My Django Study</title></head><body>Hello My first page</body></html>")


def home(request):
    #return HttpResponse("hello home")
    logo="FACEBOOK"
    a=20
    b=30
    c=a+b

    args={'logoName':logo,'val':c}
    return render(request,'index.html',args)